//
//  segueMenuViwe.swift
//  cc
//
//  Created by eyas seyam on 2/11/19.
//  Copyright © 2019 eyas seyam. All rights reserved.
//

import UIKit

class segueMenuViwe: UIViewController {
    
    override func viewDidLoad() {
        NotificationCenter.default.addObserver(self, selector: #selector(segueMenuViwe.ChangeVC(notification:)), name: NSNotification.Name(rawValue: "ChangeVC"), object: nil)
    }
    
    
    @objc func ChangeVC (notification : NSNotification) {
        if let Dic = notification.userInfo as? [String : AnyObject] {
            if let Name = Dic["ToVC"] as? String {
            performSegue(withIdentifier: Name , sender: nil)
            }
        }

    }
    
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        performSegue(withIdentifier: "Main", sender: nil)
       // RadioClass.ToggleMenu()
    }
    
}
