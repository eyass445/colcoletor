 //
//  RadioClass.swift
//  cc
//
//  Created by eyas seyam on 2/13/19.
//  Copyright © 2019 eyas seyam. All rights reserved.
//

import Foundation
 
 class RadioClass  {
    
    static var IsMenu : Bool = false
    
    static func ToggleMenu()  {
        if IsMenu {
            NotificationCenter.default.post(name: NSNotification.Name("HideMenu"),object: nil)
            IsMenu = false
        }else {
            NotificationCenter.default.post(name: NSNotification.Name("ShowMenu"),object: nil)
            IsMenu = true
        }
    }
 
}
