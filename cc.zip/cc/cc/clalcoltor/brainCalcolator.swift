//
//  brainCalcolator.swift
//  cc
//
//  Created by eyas seyam on 1/22/19.
//  Copyright © 2019 eyas seyam. All rights reserved.
//

import Foundation

class brainCalcoletor {
    
    
    func Restart()  {
        NumwihtArray = []
    }
    
    
    
    func add(number : Double , oprashen : Character )  {
        NumwihtArray.append(CalcElment(num : number , op : oprashen))
    }
    
    
    typealias CalcElment = (num : Double , op : Character)
    private var NumwihtArray : [CalcElment] = []
    
    
    
    
    func resalt () -> String {
        cololetorMultipyAndDevaesed()
        cololetorAllMinis()
        return String(NumwihtArray.reduce(0, {$0 + $1.num}))
    }
    
    
    
    
    
    
    func cololetorMultipyAndDevaesed (){
        
        for (index,courrent) in NumwihtArray.enumerated() {
            if courrent.op == "x"  || courrent.op == "/" {
                let afterCurrent = NumwihtArray[index + 1]
                var newcolc :  CalcElment?
                if courrent.op == "x" {
                    newcolc = CalcElment( num : courrent.num * afterCurrent.num , op : afterCurrent.op )
                    
                } else if courrent.op == "/" {
                    newcolc = CalcElment( num : courrent.num / afterCurrent.num , op : afterCurrent.op )
                    
                }
                NumwihtArray.remove(at: index) ;  NumwihtArray.remove(at: index)
                NumwihtArray.insert(newcolc!, at: index)
                cololetorMultipyAndDevaesed ()
                break
                
            }
   }
        
    }
    
    
    func cololetorAllMinis () {
        
        
        for (index,courrent) in NumwihtArray.enumerated() {
            if courrent.op == "-"  {
                let afterCurrent = NumwihtArray[index + 1]
                let newcolc : CalcElment = CalcElment( num : courrent.num - afterCurrent.num , op : "+" )
                NumwihtArray.remove(at: index) ;  NumwihtArray.remove(at: index)
                NumwihtArray.insert(newcolc, at: index)
                cololetorMultipyAndDevaesed ()
                break
                
            }
        }
    }
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
}

