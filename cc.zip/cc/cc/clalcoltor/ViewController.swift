//
//  ViewController.swift
//  cc
//
//  Created by eyas seyam on 1/21/19.
//  Copyright © 2019 eyas seyam. All rights reserved.
//

import UIKit


class ViewController: UIViewController {
    
    
    
    @IBAction func MenuAction(_ sender: UIButton) {
        
        RadioClass.ToggleMenu()
    }
    
    
    override var preferredStatusBarStyle: UIStatusBarStyle {
        return.lightContent
    }

    
    
    @IBOutlet weak var resaltLable: UILabel!
    
    let brain : brainCalcoletor = brainCalcoletor()
    
    
    
    
    
    @IBAction func ButtonsAction(_ sender: UIButton) {
        
        if resaltLable.text == "0"{
           resaltLable.text = ""
        }
        
        if sender.tag == -3 {
            
            if !resaltLable.text!.contains(".") {
                
             resaltLable.text = resaltLable.text! + "."
            }
        } else {
            resaltLable.text = resaltLable.text! + String(sender.tag)
        }
    }
    
    
    
    
  
    @IBAction func oprashen( _ sender: UIButton) {
      
        brain.add(number: Double(resaltLable.text!)! , oprashen: Character(sender.titleLabel!.text!))
        
        if sender.titleLabel!.text == "=" {
            resaltLable.text = brain.resalt()
            brain.Restart()
        } else {
        resaltLable.text = "0"
    }
}
    
   
    
    
    
    @IBAction func ACbutton(_ sender: UIButton) {
        resaltLable.text = "0"
        brain.Restart()

    }
    
    
    @IBAction func PMbutton(_ sender: UIButton) {
        
        resaltLable.text = String (Double(resaltLable.text!)! * -1 )
    }
    
    
    
    
    
    @IBAction func bersantbutton(_ sender: UIButton) {
        
        resaltLable.text = String (Double(resaltLable.text!)! / 100 )

    }
    
  
 
    
    
}
