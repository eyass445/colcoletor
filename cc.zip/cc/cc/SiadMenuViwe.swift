//
//  SiadMenuViwe.swift
//  cc
//
//  Created by eyas seyam on 2/11/19.
//  Copyright © 2019 eyas seyam. All rights reserved.
//

import UIKit

class SiadMenuViwe: UIViewController  {
    
   
    
    
    @IBAction func ActionButton(_ sender: UIButton) {
        
        var ToVC : String = ""
                if sender.tag == 0 {
                   ToVC = "Main"
                }else if sender.tag == 1 {
                   ToVC = "AboutUS"
                }else if sender.tag == 2 {
                    ToVC = "countactUS"
        
    }
    
   
        
        NotificationCenter.default.post(name: NSNotification.Name(rawValue: "ChangeVC"), object: nil, userInfo: ["ToVC" : ToVC])
    }
    
    
}
