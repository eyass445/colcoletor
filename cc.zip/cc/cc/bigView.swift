//
//  bigView.swift
//  cc
//
//  Created by eyas seyam on 2/13/19.
//  Copyright © 2019 eyas seyam. All rights reserved.
//

import UIKit

class bigView : UIViewController {
    
    
    override var preferredStatusBarStyle: UIStatusBarStyle {
        return .lightContent 
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        NotificationCenter.default.addObserver(self, selector: #selector(bigView.HideMenu), name: NSNotification.Name(rawValue: "HideMenu"), object: nil)
        
        
        NotificationCenter.default.addObserver(self, selector: #selector(bigView.ShowMenu), name: NSNotification.Name(rawValue: "ShowMenu"), object: nil)
        
        
        
        
        
        
        
        
    }
    
    
    
    @IBOutlet weak var SideMenu: NSLayoutConstraint!
    
    
    
    @objc func HideMenu () {
        
        SideMenu.constant = 0
        
        UIView.animate(withDuration: 0.5){
            self.view.layoutIfNeeded()}
        
    }
    
    
    @objc func ShowMenu () {
        
        
        SideMenu.constant = self.view.frame.size.width * 0.7
        
                UIView.animate(withDuration: 0.5){
        self.view.layoutIfNeeded()
            }
        
    }
    
    
    
    
    
}
